<?php
update_option('ep_fitness_signup-template', 'signup-style-2'); 
update_option('ep_fitness_profile-template', 'style-1' ); 
update_option('ep_fitness_profile-public', 'style-2' ); 
update_option('ep_fitness_post_approved', 'yes' ); 
update_option('_ep_fitness_hide_admin_bar', 'yes' ); 


?>
