<?php

namespace Stripe\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements ExceptionInterface
{
}
