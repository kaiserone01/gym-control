<?php
echo "hello";
exit;
?>